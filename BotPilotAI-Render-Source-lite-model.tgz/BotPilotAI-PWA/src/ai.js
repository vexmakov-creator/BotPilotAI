import { z } from 'zod/v4';

const ActionType = z.enum([
  'create_text_channel',
  'create_voice_channel',
  'create_category',
  'rename_channel',
  'delete_channel',
  'move_channel',
  'set_channel_topic',
  'set_slowmode',
  'send_message',
  'create_role',
  'rename_role',
  'delete_role',
  'rename_server'
]);

const Embed = z.object({
  title: z.string().max(256).nullable(),
  description: z.string().max(6000).nullable(),
  color: z.number().int().min(0).max(16777215).nullable(),
  image_url: z.string().url().nullable(),
}).nullable();

const Action = z.object({
  type: ActionType,
  ref: z.string().regex(/^[a-zA-Z][a-zA-Z0-9_-]{0,63}$/).nullable(),
  channel_id: z.string().nullable(),
  role_id: z.string().nullable(),
  name: z.string().max(100).nullable(),
  content: z.string().max(6000).nullable(),
  embed: Embed,
  topic: z.string().max(1024).nullable(),
  parent_id: z.string().nullable(),
  parent_ref: z.string().nullable(),
  channel_ref: z.string().nullable(),
  seconds: z.number().int().min(0).max(21600).nullable(),
  reason: z.string().max(512).nullable(),
});

const Plan = z.object({
  summary: z.string().max(1000),
  actions: z.array(Action).max(25),
});

function riskFor(actions) {
  if (actions.some((a) => ['delete_channel', 'delete_role'].includes(a.type))) return 'high';
  if (actions.some((a) => ['rename_server', 'move_channel', 'create_role', 'rename_role', 'rename_channel', 'create_text_channel', 'create_voice_channel', 'create_category'].includes(a.type))) return 'medium';
  return 'low';
}

const GROQ_ENDPOINT = process.env.GROQ_BASE_URL || 'https://api.groq.com/openai/v1/chat/completions';
const DEFAULT_GROQ_MODEL = 'llama-3.1-8b-instant';

const actionShape = '{"type":"create_text_channel|create_voice_channel|create_category|rename_channel|delete_channel|move_channel|set_channel_topic|set_slowmode|send_message|create_role|rename_role|delete_role|rename_server","ref":"reference or null","channel_id":"existing ID or null","role_id":"existing ID or null","name":"name or null","content":"plain message or null","embed":{"title":"title or null","description":"description or null","color":"integer or null","image_url":"URL or null"},"topic":"topic or null","parent_id":"existing category ID or null","parent_ref":"ref of an earlier create_category action or null","channel_ref":"ref of an earlier channel action or null","seconds":"integer 0-21600 or null","reason":"short reason or null"}';

export class AIPlanner {
  constructor() {
    this.apiKey = String(process.env.GROQ_API_KEY || '').trim();
    this.model = String(process.env.GROQ_MODEL || '').trim() || DEFAULT_GROQ_MODEL;
  }

  async plan(request, snapshot) {
    if (!this.apiKey) throw new Error('A IA ainda não foi configurada neste servidor. Adicione GROQ_API_KEY nas variáveis do Render.');

    const instructions = [
      'You are a Discord server administration planner.',
      'Return a minimal, exact sequence of allowed actions as JSON only.',
      'Use Brazilian Portuguese in summary. Never invent existing Discord IDs.',
      'For dependent creates, use refs: create_category ref="cat_valorant", then create_text_channel parent_ref="cat_valorant" ref="chan_contas_nfa", then send_message channel_ref="chan_contas_nfa".',
      'The executor resolves refs in order, so never put a fake Discord ID in parent_id or channel_id.',
      'For a visual panel use send_message with embed {title, description, color, image_url:null}; put the full readable text in embed.description.',
      'Do not plan bans, kicks, mass-DMs, token changes, permission escalation, webhooks, or unsupported actions.',
      'Do not delete, rename, or modify existing objects unless explicitly requested.',
      `Every action must contain all fields exactly as follows: ${actionShape}`,
      'Use null for every field that does not apply. Return no markdown and no extra keys.',
    ].join('\n');

    const response = await fetch(GROQ_ENDPOINT, {
      method: 'POST',
      headers: { Authorization: `Bearer ${this.apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: this.model,
        temperature: 0,
        max_tokens: 1200,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: instructions },
          { role: 'user', content: JSON.stringify({ user_request: request, discord_state: snapshot }) },
        ],
      }),
    });

    if (!response.ok) {
      let providerMessage = '';
      try { const body = await response.json(); providerMessage = typeof body?.error?.message === 'string' ? body.error.message : ''; } catch {}
      throw new Error(`Falha na API da Groq (${response.status})${providerMessage ? `: ${providerMessage}` : ''}`);
    }

    const payload = await response.json();
    const content = payload?.choices?.[0]?.message?.content;
    if (typeof content !== 'string' || !content.trim()) throw new Error('A Groq não retornou um plano válido.');

    let parsedJson;
    try { parsedJson = JSON.parse(content); } catch { throw new Error('A Groq retornou uma resposta que não é JSON válido.'); }
    const parsed = Plan.safeParse(parsedJson);
    if (!parsed.success) throw new Error('A Groq retornou um plano fora do formato permitido.');
    return { ...parsed.data, risk: riskFor(parsed.data.actions) };
  }
}
