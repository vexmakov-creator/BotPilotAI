import { Client, GatewayIntentBits } from 'discord.js';
import { decryptSecret } from './store.js';

function waitForReady(client, timeoutMs = 20000) {
  if (client.isReady()) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Discord connection timed out.')), timeoutMs);
    client.once('ready', () => { clearTimeout(timer); resolve(); });
    client.once('error', (err) => { clearTimeout(timer); reject(err); });
  });
}

export class BotManager {
  constructor() {
    this.clients = new Map();
    this.errors = new Map();
  }

  status(botId) {
    const client = this.clients.get(botId);
    if (client?.isReady()) return { status: 'online', latency: client.ws.ping };
    if (client) return { status: 'connecting', latency: null };
    if (this.errors.has(botId)) return { status: 'error', latency: null, error: this.errors.get(botId) };
    return { status: 'offline', latency: null };
  }

  async start(record) {
    if (this.clients.get(record.id)?.isReady()) return this.clients.get(record.id);
    await this.stop(record.id);
    this.errors.delete(record.id);

    const client = new Client({ intents: [GatewayIntentBits.Guilds] });
    this.clients.set(record.id, client);
    try {
      await client.login(decryptSecret(record.encryptedToken));
      await waitForReady(client);
      return client;
    } catch (error) {
      try { client.destroy(); } catch {}
      this.clients.delete(record.id);
      this.errors.set(record.id, error?.message || 'Unknown Discord error');
      throw error;
    }
  }

  async stop(botId) {
    const client = this.clients.get(botId);
    if (client) {
      try { client.destroy(); } catch {}
      this.clients.delete(botId);
    }
  }

  getReady(botId) {
    const client = this.clients.get(botId);
    if (!client?.isReady()) throw new Error('Bot is not online.');
    return client;
  }

  async guilds(botId) {
    const client = this.getReady(botId);
    return client.guilds.cache.map((guild) => ({
      id: guild.id,
      name: guild.name,
      icon: guild.iconURL({ size: 128 }),
      memberCount: guild.memberCount,
    })).sort((a, b) => a.name.localeCompare(b.name));
  }

  async snapshot(botId, guildId) {
    const client = this.getReady(botId);
    const guild = await client.guilds.fetch(guildId);
    const channels = await guild.channels.fetch();
    const roles = await guild.roles.fetch();
    return {
      guild: { id: guild.id, name: guild.name },
      channels: [...channels.values()].filter(Boolean).map((c) => ({
        id: c.id,
        name: c.name,
        type: c.type,
        parentId: c.parentId ?? null,
        position: c.rawPosition,
      })),
      roles: [...roles.values()].map((r) => ({
        id: r.id,
        name: r.name,
        position: r.position,
        managed: r.managed,
      })),
    };
  }
}
