import { ChannelType } from 'discord.js';

function required(value, name) {
  if (value === null || value === undefined || value === '') throw new Error(`${name} is required for this action.`);
  return value;
}

function resolveRef(value, refs, name) {
  if (!value) return null;
  if (refs.has(value)) return refs.get(value);
  if (/^\d{15,25}$/.test(value)) return value;
  throw new Error(`${name} references an unknown action: ${value}`);
}

function messagePayload(action) {
  const payload = { allowedMentions: { parse: [] } };
  if (action.content) payload.content = action.content;
  if (action.embed) {
    const embed = {};
    if (action.embed.title) embed.title = action.embed.title;
    if (action.embed.description) embed.description = action.embed.description;
    if (action.embed.color !== null && action.embed.color !== undefined) embed.color = action.embed.color;
    if (action.embed.image_url) embed.image = { url: action.embed.image_url };
    payload.embeds = [embed];
  }
  if (!payload.content && !payload.embeds) throw new Error('Message must include content or embed.');
  return payload;
}

export async function executePlan(client, guildId, plan) {
  const guild = await client.guilds.fetch(guildId);
  const results = [];
  const refs = new Map();

  for (const action of plan.actions) {
    try {
      let detail = '';
      let createdId = null;
      switch (action.type) {
        case 'create_text_channel': {
          const parent = action.parent_ref ? resolveRef(action.parent_ref, refs, 'parent_ref') : action.parent_id || undefined;
          const channel = await guild.channels.create({ name: required(action.name, 'name'), type: ChannelType.GuildText, parent, reason: action.reason || 'BotPilot AI' });
          createdId = channel.id;
          detail = `Canal de texto criado: #${channel.name}`;
          break;
        }
        case 'create_voice_channel': {
          const parent = action.parent_ref ? resolveRef(action.parent_ref, refs, 'parent_ref') : action.parent_id || undefined;
          const channel = await guild.channels.create({ name: required(action.name, 'name'), type: ChannelType.GuildVoice, parent, reason: action.reason || 'BotPilot AI' });
          createdId = channel.id;
          detail = `Canal de voz criado: ${channel.name}`;
          break;
        }
        case 'create_category': {
          const channel = await guild.channels.create({ name: required(action.name, 'name'), type: ChannelType.GuildCategory, reason: action.reason || 'BotPilot AI' });
          createdId = channel.id;
          detail = `Categoria criada: ${channel.name}`;
          break;
        }
        case 'rename_channel': {
          const channel = await guild.channels.fetch(resolveRef(required(action.channel_id, 'channel_id'), refs, 'channel_id'));
          await channel.setName(required(action.name, 'name'), action.reason || 'BotPilot AI');
          detail = `Canal renomeado para ${action.name}`;
          break;
        }
        case 'delete_channel': {
          const channel = await guild.channels.fetch(resolveRef(required(action.channel_id, 'channel_id'), refs, 'channel_id'));
          const oldName = channel.name;
          await channel.delete(action.reason || 'BotPilot AI');
          detail = `Canal removido: ${oldName}`;
          break;
        }
        case 'move_channel': {
          const channel = await guild.channels.fetch(resolveRef(required(action.channel_id, 'channel_id'), refs, 'channel_id'));
          const parent = action.parent_ref ? resolveRef(action.parent_ref, refs, 'parent_ref') : required(action.parent_id, 'parent_id');
          await channel.setParent(parent, { lockPermissions: false, reason: action.reason || 'BotPilot AI' });
          detail = `Canal movido: ${channel.name}`;
          break;
        }
        case 'set_channel_topic': {
          const channel = await guild.channels.fetch(resolveRef(required(action.channel_id, 'channel_id'), refs, 'channel_id'));
          if (typeof channel.setTopic !== 'function') throw new Error('This channel does not support topics.');
          await channel.setTopic(action.topic ?? null, action.reason || 'BotPilot AI');
          detail = `Tópico atualizado em #${channel.name}`;
          break;
        }
        case 'set_slowmode': {
          const channel = await guild.channels.fetch(resolveRef(required(action.channel_id, 'channel_id'), refs, 'channel_id'));
          if (typeof channel.setRateLimitPerUser !== 'function') throw new Error('This channel does not support slowmode.');
          await channel.setRateLimitPerUser(required(action.seconds, 'seconds'), action.reason || 'BotPilot AI');
          detail = `Modo lento atualizado em #${channel.name}`;
          break;
        }
        case 'send_message': {
          const channelId = action.channel_ref ? resolveRef(action.channel_ref, refs, 'channel_ref') : resolveRef(required(action.channel_id, 'channel_id'), refs, 'channel_id');
          const channel = await guild.channels.fetch(channelId);
          if (!channel.isTextBased() || typeof channel.send !== 'function') throw new Error('Target channel cannot receive messages.');
          await channel.send(messagePayload(action));
          detail = `Mensagem enviada em #${channel.name}`;
          break;
        }
        case 'create_role': {
          const role = await guild.roles.create({ name: required(action.name, 'name'), reason: action.reason || 'BotPilot AI' });
          createdId = role.id;
          detail = `Cargo criado: ${role.name}`;
          break;
        }
        case 'rename_role': {
          const role = await guild.roles.fetch(resolveRef(required(action.role_id, 'role_id'), refs, 'role_id'));
          if (!role || role.managed) throw new Error('Role cannot be edited.');
          await role.setName(required(action.name, 'name'), action.reason || 'BotPilot AI');
          detail = `Cargo renomeado para ${action.name}`;
          break;
        }
        case 'delete_role': {
          const role = await guild.roles.fetch(resolveRef(required(action.role_id, 'role_id'), refs, 'role_id'));
          if (!role || role.managed) throw new Error('Role cannot be deleted.');
          const oldName = role.name;
          await role.delete(action.reason || 'BotPilot AI');
          detail = `Cargo removido: ${oldName}`;
          break;
        }
        case 'rename_server': {
          await guild.setName(required(action.name, 'name'), action.reason || 'BotPilot AI');
          detail = `Servidor renomeado para ${action.name}`;
          break;
        }
        default:
          throw new Error(`Unsupported action: ${action.type}`);
      }
      if (action.ref && createdId) refs.set(action.ref, createdId);
      results.push({ type: action.type, ref: action.ref || null, ok: true, detail });
    } catch (error) {
      results.push({ type: action.type, ref: action.ref || null, ok: false, detail: error?.message || 'Unknown error' });
      break;
    }
  }
  return results;
}
