import crypto from 'node:crypto';
import express from 'express';
import { BotManager } from './botManager.js';
import { AIPlanner } from './ai.js';
import { appendHistory, encryptSecret, loadStore, publicBot, saveStore, sha256 } from './store.js';
import { executePlan } from './actions.js';

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '256kb' }));
app.use(express.static('web', { etag: true, maxAge: process.env.NODE_ENV === 'production' ? '1h' : 0 }));

const state = loadStore();
const manager = new BotManager();
const planner = new AIPlanner();
const pendingPlans = new Map();
const PORT = Number(process.env.PORT || 8787);

function persist() { saveStore(state); }
function cleanToken(token) { return String(token || '').trim().replace(/^Bot\s+/i, ''); }

async function validateDiscordBotToken(token) {
  const response = await fetch('https://discord.com/api/v10/users/@me', { headers: { Authorization: `Bot ${token}` } });
  if (!response.ok) throw new Error('Token de bot inválido ou recusado pelo Discord.');
  const user = await response.json();
  if (!user.bot) throw new Error('Use somente token de uma conta de BOT do Discord, não token de usuário.');
  return user;
}

function auth(req, res, next) {
  const raw = req.headers.authorization || '';
  const secret = raw.startsWith('Bearer ') ? raw.slice(7) : '';
  const device = state.devices.find((d) => d.secretHash === sha256(secret));
  if (!device) return res.status(401).json({ error: 'Sessão do dispositivo inválida.' });
  req.device = device;
  next();
}

function ownedBot(req, res) {
  const bot = state.bots.find((b) => b.id === req.params.botId && b.ownerId === req.device.id);
  if (!bot) res.status(404).json({ error: 'Bot não encontrado.' });
  return bot;
}

function runtimeView(bot) { return publicBot(bot, manager.status(bot.id)); }

app.get('/health', (_req, res) => res.json({ ok: true, service: 'BotPilot AI', time: new Date().toISOString() }));

app.post('/api/device/register', (req, res) => {
  const installId = String(req.body?.installId || '').trim();
  if (!installId || installId.length > 128) return res.status(400).json({ error: 'installId inválido.' });
  let device = state.devices.find((d) => d.installId === installId);
  const secret = crypto.randomBytes(32).toString('base64url');
  if (!device) {
    device = { id: crypto.randomUUID(), installId, secretHash: sha256(secret), createdAt: new Date().toISOString() };
    state.devices.push(device);
  } else {
    device.secretHash = sha256(secret);
  }
  persist();
  res.json({ deviceId: device.id, deviceSecret: secret });
});

app.use('/api', auth);

app.get('/api/bots', (req, res) => {
  res.json(state.bots.filter((b) => b.ownerId === req.device.id).map(runtimeView));
});

app.post('/api/bots', async (req, res) => {
  try {
    const token = cleanToken(req.body?.token);
    if (token.length < 20 || token.length > 256) return res.status(400).json({ error: 'Token inválido.' });
    const user = await validateDiscordBotToken(token);
    let bot = state.bots.find((b) => b.ownerId === req.device.id && b.discordUserId === user.id);
    if (bot) {
      bot.encryptedToken = encryptSecret(token);
      bot.username = user.global_name || user.username;
      bot.avatar = user.avatar || null;
      bot.active = true;
      bot.updatedAt = new Date().toISOString();
    } else {
      bot = {
        id: crypto.randomUUID(), ownerId: req.device.id, discordUserId: user.id,
        username: user.global_name || user.username, avatar: user.avatar || null,
        encryptedToken: encryptSecret(token), active: true,
        createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
      };
      state.bots.push(bot);
    }
    persist();
    await manager.start(bot);
    res.status(201).json(runtimeView(bot));
  } catch (error) {
    res.status(400).json({ error: error?.message || 'Não foi possível adicionar o bot.' });
  }
});

app.post('/api/bots/:botId/start', async (req, res) => {
  const bot = ownedBot(req, res); if (!bot) return;
  try {
    bot.active = true; bot.updatedAt = new Date().toISOString(); persist();
    await manager.start(bot);
    res.json(runtimeView(bot));
  } catch (error) { res.status(400).json({ error: error?.message || 'Falha ao iniciar.' }); }
});

app.post('/api/bots/:botId/stop', async (req, res) => {
  const bot = ownedBot(req, res); if (!bot) return;
  await manager.stop(bot.id);
  bot.active = false; bot.updatedAt = new Date().toISOString(); persist();
  res.json(runtimeView(bot));
});

app.delete('/api/bots/:botId', async (req, res) => {
  const bot = ownedBot(req, res); if (!bot) return;
  await manager.stop(bot.id);
  state.bots = state.bots.filter((b) => b.id !== bot.id);
  state.history = state.history.filter((h) => h.botId !== bot.id);
  persist();
  res.status(204).end();
});

app.get('/api/bots/:botId/guilds', async (req, res) => {
  const bot = ownedBot(req, res); if (!bot) return;
  try { res.json(await manager.guilds(bot.id)); }
  catch (error) { res.status(400).json({ error: error?.message || 'Falha ao carregar servidores.' }); }
});

app.get('/api/bots/:botId/history', (req, res) => {
  const bot = ownedBot(req, res); if (!bot) return;
  res.json(state.history.filter((h) => h.botId === bot.id).slice(0, 50));
});

app.post('/api/bots/:botId/ai/plan', async (req, res) => {
  const bot = ownedBot(req, res); if (!bot) return;
  try {
    const guildId = String(req.body?.guildId || '');
    const message = String(req.body?.message || '').trim();
    if (!guildId || !message || message.length > 4000) return res.status(400).json({ error: 'Pedido ou servidor inválido.' });
    const snapshot = await manager.snapshot(bot.id, guildId);
    const plan = await planner.plan(message, snapshot);
    const planId = crypto.randomUUID();
    pendingPlans.set(planId, { ownerId: req.device.id, botId: bot.id, guildId, request: message, plan, expiresAt: Date.now() + 10 * 60 * 1000 });
    res.json({ planId, ...plan, requiresExtraConfirmation: plan.risk === 'high' });
  } catch (error) { res.status(400).json({ error: error?.message || 'Falha ao criar plano.' }); }
});

app.post('/api/bots/:botId/ai/execute', async (req, res) => {
  const bot = ownedBot(req, res); if (!bot) return;
  const planId = String(req.body?.planId || '');
  const pending = pendingPlans.get(planId);
  if (!pending || pending.ownerId !== req.device.id || pending.botId !== bot.id || pending.expiresAt < Date.now()) {
    pendingPlans.delete(planId);
    return res.status(400).json({ error: 'Plano inválido ou expirado. Gere um novo plano.' });
  }
  try {
    const client = manager.getReady(bot.id);
    const results = await executePlan(client, pending.guildId, pending.plan);
    pendingPlans.delete(planId);
    appendHistory(state, { botId: bot.id, guildId: pending.guildId, request: pending.request, summary: pending.plan.summary, risk: pending.plan.risk, results });
    persist();
    res.json({ summary: pending.plan.summary, results });
  } catch (error) { res.status(400).json({ error: error?.message || 'Falha ao executar plano.' }); }
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'Erro interno.' });
});

app.listen(PORT, '0.0.0.0', async () => {
  console.log(`BotPilot AI backend listening on :${PORT}`);
  const active = state.bots.filter((b) => b.active);
  await Promise.allSettled(active.map((bot) => manager.start(bot)));
  console.log(`Restored ${active.length} configured bot(s).`);
});
