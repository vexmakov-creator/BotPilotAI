import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const dataFile = process.env.DATA_FILE || path.resolve('data/store.json');
const keyFile = path.resolve('data/.master-key');

function getMasterKey() {
  if (process.env.MASTER_KEY) {
    const key = Buffer.from(process.env.MASTER_KEY, 'base64');
    if (key.length !== 32) throw new Error('MASTER_KEY must decode to exactly 32 bytes.');
    return key;
  }
  if (process.env.NODE_ENV === 'production') {
    throw new Error('MASTER_KEY is required in production.');
  }
  fs.mkdirSync(path.dirname(keyFile), { recursive: true });
  if (!fs.existsSync(keyFile)) fs.writeFileSync(keyFile, crypto.randomBytes(32).toString('base64'), { mode: 0o600 });
  return Buffer.from(fs.readFileSync(keyFile, 'utf8').trim(), 'base64');
}

const masterKey = getMasterKey();

function initialState() {
  return { devices: [], bots: [], history: [] };
}

export function loadStore() {
  fs.mkdirSync(path.dirname(dataFile), { recursive: true });
  if (!fs.existsSync(dataFile)) return initialState();
  try {
    const parsed = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
    return { ...initialState(), ...parsed };
  } catch {
    throw new Error(`Could not parse data store at ${dataFile}`);
  }
}

export function saveStore(state) {
  fs.mkdirSync(path.dirname(dataFile), { recursive: true });
  const tmp = `${dataFile}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(state, null, 2));
  fs.renameSync(tmp, dataFile);
}

export function encryptSecret(plainText) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', masterKey, iv);
  const encrypted = Buffer.concat([cipher.update(plainText, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [iv, tag, encrypted].map((b) => b.toString('base64')).join('.');
}

export function decryptSecret(payload) {
  const [ivB64, tagB64, dataB64] = payload.split('.');
  const decipher = crypto.createDecipheriv('aes-256-gcm', masterKey, Buffer.from(ivB64, 'base64'));
  decipher.setAuthTag(Buffer.from(tagB64, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(dataB64, 'base64')), decipher.final()]).toString('utf8');
}

export function sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

export function publicBot(record, runtime = {}) {
  const { encryptedToken, ...safe } = record;
  return { ...safe, ...runtime };
}

export function appendHistory(state, entry) {
  state.history.unshift({ id: crypto.randomUUID(), at: new Date().toISOString(), ...entry });
  state.history = state.history.slice(0, 200);
}
