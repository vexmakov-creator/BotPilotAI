(() => {
  'use strict';

  const state = {
    tab: 'bots', bots: [], selectedBotId: null, guilds: [], selectedGuildId: null,
    history: [], pendingPlan: null, busy: false, installPrompt: null
  };

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  const app = $('#app');
  const modalRoot = $('#modalRoot');
  const toastEl = $('#toast');
  const escapeHtml = (s = '') => String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));

  function uuid() {
    if (crypto.randomUUID) return crypto.randomUUID();
    return `${Date.now()}-${Math.random().toString(16).slice(2)}-${Math.random().toString(16).slice(2)}`;
  }

  function toast(message) {
    toastEl.textContent = message;
    toastEl.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toastEl.classList.remove('show'), 2800);
  }

  function getInstallId() {
    let id = localStorage.getItem('bp_install_id');
    if (!id) { id = uuid(); localStorage.setItem('bp_install_id', id); }
    return id;
  }

  async function ensureSession(force = false) {
    let secret = localStorage.getItem('bp_device_secret');
    if (secret && !force) return secret;
    const res = await fetch('/api/device/register', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ installId: getInstallId() })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Não foi possível iniciar a sessão.');
    localStorage.setItem('bp_device_secret', data.deviceSecret);
    return data.deviceSecret;
  }

  async function api(path, options = {}, retried = false) {
    const secret = await ensureSession();
    const headers = new Headers(options.headers || {});
    headers.set('Authorization', `Bearer ${secret}`);
    if (options.body && !headers.has('Content-Type')) headers.set('Content-Type','application/json');
    const res = await fetch(path, {...options, headers});
    if (res.status === 401 && !retried) {
      await ensureSession(true);
      return api(path, options, true);
    }
    if (res.status === 204) return null;
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `Erro ${res.status}`);
    return data;
  }

  function currentBot() { return state.bots.find(b => b.id === state.selectedBotId) || null; }
  function currentGuild() { return state.guilds.find(g => g.id === state.selectedGuildId) || null; }

  function avatarHTML(bot) {
    if (bot.avatar) {
      const src = `https://cdn.discordapp.com/avatars/${encodeURIComponent(bot.discordUserId)}/${encodeURIComponent(bot.avatar)}.png?size=128`;
      return `<div class="avatar"><img alt="" src="${src}" /></div>`;
    }
    const initial = escapeHtml((bot.username || 'B').slice(0,2).toUpperCase());
    return `<div class="avatar">${initial}</div>`;
  }

  function statusLabel(bot) {
    const map = {online:'Online', connecting:'Conectando', offline:'Offline', error:'Erro'};
    return `<span class="status ${escapeHtml(bot.status || 'offline')}">${map[bot.status] || 'Offline'}</span>`;
  }

  function renderBots() {
    const online = state.bots.filter(b => b.status === 'online').length;
    app.innerHTML = `
      <section class="hero">
        <div class="row between">
          <div>
            <h1>Seus bots, em um só lugar.</h1>
            <p>Ative seus bots e use a IA para organizar e alterar seus servidores do Discord.</p>
          </div>
        </div>
        <div class="row wrap" style="margin-top:16px">
          <span class="pill">${state.bots.length} bot${state.bots.length === 1 ? '' : 's'}</span>
          <span class="pill low">${online} online</span>
        </div>
      </section>
      <div class="section-head">
        <div><h2>Meus bots</h2><p>Toque em um bot para gerenciar.</p></div>
        <button class="btn" id="addBotBtn">+ Adicionar</button>
      </div>
      <div class="cards ${state.bots.length > 1 ? 'two' : ''}" id="botCards">
        ${state.bots.length ? state.bots.map(bot => `
          <article class="card bot-card" data-bot-id="${bot.id}">
            <div class="row between">
              <div class="row" style="min-width:0">${avatarHTML(bot)}<div style="min-width:0"><div class="bot-name">${escapeHtml(bot.username)}</div><div class="meta">${bot.active ? 'Hospedagem ativada' : 'Hospedagem pausada'}${bot.latency != null ? ` · ${Math.round(bot.latency)}ms` : ''}</div></div></div>
              ${statusLabel(bot)}
            </div>
          </article>`).join('') : `<div class="empty"><div class="big">🤖</div><strong>Nenhum bot adicionado</strong><p>Cadastre o token de um bot do Discord para começar.</p></div>`}
      </div>`;

    $('#addBotBtn').onclick = openAddBot;
    $$('.bot-card').forEach(el => el.onclick = () => openBot(el.dataset.botId));
  }

  function renderAI() {
    const bot = currentBot();
    app.innerHTML = `
      <section class="hero"><h1>Assistente de servidor ✦</h1><p>Descreva o que você quer mudar. A IA primeiro cria um plano; nada é executado sem sua confirmação.</p></section>
      <div class="section-head"><div><h2>Configuração</h2><p>Escolha o bot e o servidor.</p></div></div>
      <section class="card">
        <div class="field"><label>Bot</label><select class="select" id="aiBotSelect"><option value="">Selecione um bot</option>${state.bots.map(b => `<option value="${b.id}" ${b.id===state.selectedBotId?'selected':''}>${escapeHtml(b.username)} · ${b.status || 'offline'}</option>`).join('')}</select></div>
        <div class="field"><label>Servidor</label><select class="select" id="guildSelect" ${!bot || bot.status!=='online'?'disabled':''}><option value="">${!bot ? 'Selecione um bot primeiro' : bot.status!=='online' ? 'O bot precisa estar online' : 'Carregando servidores...'}</option></select></div>
      </section>
      <div class="section-head"><div><h2>Pedido para a IA</h2><p>Seja específico para obter um plano melhor.</p></div></div>
      <section class="ai-box">
        <textarea class="textarea" id="aiMessage" placeholder="Ex.: crie uma categoria SUPORTE com os canais dúvidas e tickets. Depois envie uma mensagem de boas-vindas em #geral."></textarea>
        <button class="btn" id="planBtn" style="width:100%;margin-top:12px" ${!bot || bot.status!=='online'?'disabled':''}>Criar plano</button>
      </section>
      ${state.pendingPlan ? planHTML(state.pendingPlan) : ''}`;

    $('#aiBotSelect').onchange = async e => {
      state.selectedBotId = e.target.value || null; state.selectedGuildId = null; state.pendingPlan = null;
      localStorage.setItem('bp_selected_bot', state.selectedBotId || '');
      renderAI();
      if (state.selectedBotId) await loadGuilds();
    };
    $('#planBtn').onclick = createPlan;
    if (bot?.status === 'online') loadGuilds().catch(err => toast(err.message));
    bindPlanButtons();
  }

  function planHTML(plan) {
    const riskName = {low:'baixo',medium:'médio',high:'alto'}[plan.risk] || plan.risk;
    return `<div class="section-head"><div><h2>Plano proposto</h2><p>Revise antes de executar.</p></div><span class="pill ${plan.risk}">Risco ${riskName}</span></div>
      <section class="card">
        <strong>${escapeHtml(plan.summary)}</strong>
        <div class="action-list">${(plan.actions || []).length ? plan.actions.map((a,i) => `<div class="action"><strong>${i+1}. ${escapeHtml(actionTitle(a))}</strong><small>${escapeHtml(actionDetail(a))}</small></div>`).join('') : '<div class="empty">A IA não encontrou uma ação segura/suportada para executar.</div>'}</div>
        ${(plan.actions || []).length ? `<div class="row" style="margin-top:14px"><button class="btn secondary" id="cancelPlanBtn" style="flex:1">Cancelar</button><button class="btn" id="executePlanBtn" style="flex:1">Executar plano</button></div>` : ''}
      </section>`;
  }

  function actionTitle(a) {
    const names = {
      create_text_channel:'Criar canal de texto', create_voice_channel:'Criar canal de voz', create_category:'Criar categoria',
      rename_channel:'Renomear canal', delete_channel:'Excluir canal', move_channel:'Mover canal', set_channel_topic:'Alterar tópico',
      set_slowmode:'Alterar modo lento', send_message:'Enviar mensagem', create_role:'Criar cargo', rename_role:'Renomear cargo',
      delete_role:'Excluir cargo', rename_server:'Renomear servidor'
    };
    return names[a.type] || a.type;
  }

  function actionDetail(a) {
    const pieces = [];
    if (a.name) pieces.push(a.name);
    if (a.content) pieces.push(`“${a.content.slice(0,120)}${a.content.length>120?'…':''}”`);
    if (a.topic) pieces.push(`Tópico: ${a.topic}`);
    if (a.seconds != null) pieces.push(`${a.seconds}s`);
    if (a.channel_id) pieces.push(`canal ${a.channel_id}`);
    if (a.role_id) pieces.push(`cargo ${a.role_id}`);
    return pieces.join(' · ') || 'Ação preparada pela IA';
  }

  function bindPlanButtons() {
    const cancel = $('#cancelPlanBtn');
    if (cancel) cancel.onclick = () => { state.pendingPlan = null; renderAI(); };
    const exec = $('#executePlanBtn');
    if (exec) exec.onclick = executePlan;
  }

  async function loadGuilds(force = false) {
    const bot = currentBot();
    if (!bot || bot.status !== 'online') return;
    if (force || !state.guilds.length || state.guilds._forBot !== bot.id) {
      state.guilds = await api(`/api/bots/${bot.id}/guilds`);
      state.guilds._forBot = bot.id;
    }
    const select = $('#guildSelect');
    if (!select) return;
    select.innerHTML = `<option value="">Selecione um servidor</option>` + state.guilds.map(g => `<option value="${g.id}" ${g.id===state.selectedGuildId?'selected':''}>${escapeHtml(g.name)}</option>`).join('');
    select.disabled = false;
    select.onchange = e => { state.selectedGuildId = e.target.value || null; localStorage.setItem(`bp_guild_${bot.id}`, state.selectedGuildId || ''); };
    const remembered = localStorage.getItem(`bp_guild_${bot.id}`);
    if (!state.selectedGuildId && remembered && state.guilds.some(g => g.id === remembered)) state.selectedGuildId = remembered;
    if (state.selectedGuildId) select.value = state.selectedGuildId;
  }

  async function createPlan() {
    const bot = currentBot();
    const message = $('#aiMessage').value.trim();
    const guildId = $('#guildSelect').value;
    if (!bot) return toast('Selecione um bot.');
    if (!guildId) return toast('Selecione um servidor.');
    if (!message) return toast('Escreva o que você quer que a IA faça.');
    const btn = $('#planBtn');
    btn.disabled = true; btn.innerHTML = '<span class="loader"></span> Analisando servidor…';
    try {
      state.selectedGuildId = guildId;
      state.pendingPlan = await api(`/api/bots/${bot.id}/ai/plan`, {method:'POST', body:JSON.stringify({guildId,message})});
      renderAI();
      setTimeout(() => $('.action-list')?.scrollIntoView({behavior:'smooth',block:'center'}), 50);
    } catch (err) { toast(err.message); btn.disabled = false; btn.textContent = 'Criar plano'; }
  }

  async function executePlan() {
    const bot = currentBot(); const plan = state.pendingPlan;
    if (!bot || !plan) return;
    if (plan.requiresExtraConfirmation || plan.risk === 'high') {
      const ok = confirm('Este plano contém ação destrutiva (como excluir canal/cargo). Deseja executar mesmo assim?');
      if (!ok) return;
    }
    const btn = $('#executePlanBtn');
    btn.disabled = true; btn.innerHTML = '<span class="loader"></span> Executando…';
    try {
      const result = await api(`/api/bots/${bot.id}/ai/execute`, {method:'POST', body:JSON.stringify({planId:plan.planId})});
      state.pendingPlan = null;
      openResult(result);
    } catch (err) { toast(err.message); btn.disabled = false; btn.textContent = 'Executar plano'; }
  }

  function openResult(result) {
    modalRoot.innerHTML = `<div class="modal-backdrop"><section class="modal"><div class="handle"></div><h3>Execução concluída</h3><div class="modal-sub">${escapeHtml(result.summary || '')}</div><div class="action-list">${(result.results||[]).map(r => `<div class="action"><strong class="${r.ok?'result-ok':'result-error'}">${r.ok?'✓':'✕'} ${escapeHtml(actionTitle({type:r.type}))}</strong><small>${escapeHtml(r.detail || '')}</small></div>`).join('')}</div><button class="btn" id="closeResultBtn" style="width:100%;margin-top:15px">Concluir</button></section></div>`;
    $('#closeResultBtn').onclick = () => { closeModal(); state.tab='history'; syncTabs(); render(); };
  }

  async function renderHistory() {
    const bot = currentBot();
    app.innerHTML = `<section class="hero"><h1>Histórico</h1><p>Veja as alterações executadas pela IA em cada bot.</p></section>
      <div class="section-head"><div><h2>Execuções recentes</h2><p>Até 50 registros por bot.</p></div></div>
      <section class="card"><div class="field"><label>Bot</label><select class="select" id="historyBotSelect"><option value="">Selecione um bot</option>${state.bots.map(b => `<option value="${b.id}" ${b.id===state.selectedBotId?'selected':''}>${escapeHtml(b.username)}</option>`).join('')}</select></div></section>
      <div id="historyList" class="cards" style="margin-top:12px">${bot ? '<div class="empty">Carregando…</div>' : '<div class="empty">Selecione um bot para ver o histórico.</div>'}</div>`;
    $('#historyBotSelect').onchange = e => { state.selectedBotId=e.target.value||null; localStorage.setItem('bp_selected_bot',state.selectedBotId||''); renderHistory(); };
    if (bot) {
      try {
        state.history = await api(`/api/bots/${bot.id}/history`);
        const list = $('#historyList');
        list.innerHTML = state.history.length ? state.history.map(h => `<article class="card history-item"><div class="row between"><span class="pill ${h.risk}">${escapeHtml(h.risk || 'low')}</span><span class="date">${new Date(h.at).toLocaleString('pt-BR')}</span></div><div class="request"><strong>Pedido:</strong> ${escapeHtml(h.request)}</div><div class="meta">${escapeHtml(h.summary || '')}</div></article>`).join('') : '<div class="empty">Ainda não há execuções para este bot.</div>';
      } catch (err) { $('#historyList').innerHTML = `<div class="empty">${escapeHtml(err.message)}</div>`; }
    }
  }

  function renderSettings() {
    const standalone = matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
    app.innerHTML = `<section class="hero"><h1>Ajustes</h1><p>Informações desta instalação e como instalar o BotPilot na Tela de Início.</p></section>
      <div class="section-head"><div><h2>Web App</h2><p>Funciona em Safari, Chrome e como PWA.</p></div></div>
      <section class="card install-card">
        <div class="row between"><div><strong>${standalone?'BotPilot já está instalado':'Instalar na Tela de Início'}</strong><div class="meta">${standalone?'Você está usando o modo aplicativo.':'No iPhone: Safari → Compartilhar → Adicionar à Tela de Início.'}</div></div><span class="pill ${standalone?'low':''}">${standalone?'Instalado':'PWA'}</span></div>
        ${state.installPrompt && !standalone ? '<button class="btn" id="installBtn" style="width:100%;margin-top:14px">Instalar agora</button>' : ''}
      </section>
      <div class="section-head"><div><h2>Segurança</h2></div></div>
      <section class="card">
        <div class="kv"><span class="key">Token do Discord</span><span class="value">Não fica salvo no navegador</span></div>
        <div class="kv"><span class="key">Sessão do dispositivo</span><span class="value">Salva localmente</span></div>
        <div class="kv"><span class="key">Conexão</span><span class="value">HTTPS recomendado</span></div>
      </section>
      <div class="section-head"><div><h2>Esta instalação</h2></div></div>
      <section class="card"><div class="help">ID local: <code>${escapeHtml(getInstallId())}</code></div><hr><button class="btn danger" id="resetSessionBtn" style="width:100%">Redefinir sessão deste navegador</button><div class="help" style="margin-top:9px">Use apenas se a sessão estiver com erro. Os bots cadastrados nesta sessão podem deixar de aparecer neste navegador.</div></section>`;
    if ($('#installBtn')) $('#installBtn').onclick = async () => { state.installPrompt.prompt(); await state.installPrompt.userChoice; state.installPrompt=null; renderSettings(); };
    $('#resetSessionBtn').onclick = () => {
      if (!confirm('Redefinir a sessão local? Faça isso apenas se estiver com problema de acesso.')) return;
      localStorage.removeItem('bp_device_secret'); localStorage.removeItem('bp_install_id'); state.bots=[]; state.selectedBotId=null; toast('Sessão redefinida.'); setTimeout(init,500);
    };
  }

  function openAddBot() {
    modalRoot.innerHTML = `<div class="modal-backdrop"><section class="modal"><div class="handle"></div><h3>Adicionar bot</h3><div class="modal-sub">Cole somente o token de BOT fornecido pelo Discord Developer Portal.</div><div class="field"><label>Token do bot</label><input class="input" id="botTokenInput" type="password" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Cole o token aqui" /></div><div class="help">O token é enviado ao backend por HTTPS, validado no Discord e armazenado criptografado. Ele não é exibido novamente.</div><div class="row" style="margin-top:17px"><button class="btn secondary" id="cancelModalBtn" style="flex:1">Cancelar</button><button class="btn" id="saveBotBtn" style="flex:1">Adicionar e ativar</button></div></section></div>`;
    $('#cancelModalBtn').onclick = closeModal;
    $('.modal-backdrop').onclick = e => { if (e.target.classList.contains('modal-backdrop')) closeModal(); };
    $('#saveBotBtn').onclick = async () => {
      const token = $('#botTokenInput').value.trim(); if (!token) return toast('Cole o token do bot.');
      const btn = $('#saveBotBtn'); btn.disabled=true; btn.innerHTML='<span class="loader"></span> Conectando…';
      try { const bot = await api('/api/bots',{method:'POST',body:JSON.stringify({token})}); closeModal(); toast(`${bot.username} foi adicionado.`); await loadBots(); state.selectedBotId=bot.id; renderBots(); }
      catch (err) { toast(err.message); btn.disabled=false; btn.textContent='Adicionar e ativar'; }
    };
  }

  function closeModal() { modalRoot.innerHTML=''; }

  function openBot(botId) {
    const bot = state.bots.find(b => b.id===botId); if (!bot) return;
    state.selectedBotId=botId; localStorage.setItem('bp_selected_bot',botId);
    modalRoot.innerHTML = `<div class="modal-backdrop"><section class="modal"><div class="handle"></div><div class="row between"><div class="row">${avatarHTML(bot)}<div><h3 style="margin:0">${escapeHtml(bot.username)}</h3><div class="meta">Discord Bot · ${escapeHtml(bot.discordUserId)}</div></div></div>${statusLabel(bot)}</div><hr><div class="kv"><span class="key">Hospedagem</span><span class="value">${bot.active?'Ativada':'Pausada'}</span></div><div class="kv"><span class="key">Status</span><span class="value">${escapeHtml(bot.status || 'offline')}</span></div><div class="kv"><span class="key">Latência</span><span class="value">${bot.latency != null ? `${Math.round(bot.latency)} ms` : '—'}</span></div>${bot.error?`<div class="help" style="color:#ff9aaa;margin-top:10px">${escapeHtml(bot.error)}</div>`:''}<div class="row" style="margin-top:16px"><button class="btn ${bot.active?'secondary':''}" id="toggleBotBtn" style="flex:1">${bot.active?'Desativar':'Ativar'}</button><button class="btn" id="useAIBtn" style="flex:1" ${bot.status!=='online'?'disabled':''}>Usar IA</button></div><button class="btn danger" id="deleteBotBtn" style="width:100%;margin-top:10px">Remover bot</button><button class="btn ghost" id="closeBotBtn" style="width:100%;margin-top:10px">Fechar</button></section></div>`;
    $('#closeBotBtn').onclick=closeModal;
    $('#useAIBtn').onclick=()=>{closeModal();state.tab='ai';state.guilds=[];syncTabs();renderAI();};
    $('#toggleBotBtn').onclick=async()=>{try{await api(`/api/bots/${bot.id}/${bot.active?'stop':'start'}`,{method:'POST'});await loadBots();closeModal();renderBots();toast(bot.active?'Bot desativado.':'Bot ativado.');}catch(err){toast(err.message);}};
    $('#deleteBotBtn').onclick=async()=>{if(!confirm(`Remover ${bot.username} do BotPilot?`))return;try{await api(`/api/bots/${bot.id}`,{method:'DELETE'});closeModal();state.selectedBotId=null;await loadBots();renderBots();toast('Bot removido.');}catch(err){toast(err.message);}};
  }

  async function loadBots() {
    state.bots = await api('/api/bots');
    const remembered = localStorage.getItem('bp_selected_bot');
    if ((!state.selectedBotId || !state.bots.some(b=>b.id===state.selectedBotId)) && remembered && state.bots.some(b=>b.id===remembered)) state.selectedBotId=remembered;
    if (!state.selectedBotId && state.bots.length) state.selectedBotId=state.bots[0].id;
  }

  function syncTabs() { $$('.tab').forEach(t=>t.classList.toggle('active',t.dataset.tab===state.tab)); }
  function render() {
    syncTabs();
    if (state.tab==='bots') renderBots();
    else if (state.tab==='ai') renderAI();
    else if (state.tab==='history') renderHistory();
    else renderSettings();
  }

  async function init() {
    app.innerHTML='<div class="empty"><span class="loader"></span><p>Conectando ao BotPilot…</p></div>';
    try { await ensureSession(); await loadBots(); render(); }
    catch (err) { app.innerHTML=`<div class="empty"><div class="big">⚠️</div><strong>Não foi possível conectar</strong><p>${escapeHtml(err.message)}</p><button class="btn" id="retryBtn">Tentar novamente</button></div>`; $('#retryBtn').onclick=init; }
  }

  $$('.tab').forEach(t => t.onclick = () => { state.tab=t.dataset.tab; state.pendingPlan=null; state.guilds=[]; render(); });
  $('#refreshBtn').onclick = async () => { try { await loadBots(); state.guilds=[]; render(); toast('Atualizado.'); } catch(err) { toast(err.message); } };
  window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); state.installPrompt=e; if(state.tab==='settings') renderSettings(); });
  if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(()=>{}));
  init();
})();
