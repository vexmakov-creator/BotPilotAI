# BotPilot AI — versão Web App (PWA)

Esta versão não precisa de Xcode. O painel web está em `backend/web/` e é servido pelo mesmo backend Node.js.

## Como funciona

`iPhone/Safari -> BotPilot PWA -> Backend 24/7 -> Discord`

`                                      -> OpenAI`

O usuário do painel só precisa cadastrar o **token do BOT do Discord**. A chave da OpenAI e a chave de criptografia ficam somente no servidor.

## Recursos da Web App

- Instalação na Tela de Início do iPhone (PWA).
- Cadastro do bot por token.
- Ativar, pausar e remover bots.
- Ver status e latência.
- Selecionar o servidor onde o bot está.
- Pedir alterações em português para a IA.
- Revisar o plano antes da execução.
- Confirmação extra para ações destrutivas.
- Histórico de alterações.
- Token do bot nunca é salvo no navegador nem retornado pela API.
- Funciona mesmo depois de fechar o Safari, desde que o backend esteja hospedado em um serviço persistente.

## Rodar localmente

Entre na pasta `backend`:

```bash
cp .env.example .env
npm install
npm start
```

Abra `http://localhost:8787`.

## Variáveis necessárias

```env
PORT=8787
NODE_ENV=production
OPENAI_API_KEY=SUA_CHAVE_OPENAI
OPENAI_MODEL=gpt-5.6
MASTER_KEY=UMA_CHAVE_BASE64_DE_32_BYTES
DATA_FILE=/data/store.json
```

Gere `MASTER_KEY` com:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

## Hospedagem

Use um host que mantenha um processo Node.js ativo e permita conexão persistente com o Discord Gateway. O backend precisa permanecer ligado para os bots continuarem online.

Depois de hospedado em HTTPS, basta abrir a URL no Safari do iPhone e escolher:

**Compartilhar -> Adicionar à Tela de Início**

O ícone `BotPilot` será instalado e abrirá em modo standalone, como um aplicativo.

## Importante

A Vercel é ótima para o frontend, mas este projeto também mantém conexões persistentes com o Discord Gateway. Por isso, para o pacote completo, prefira um host de processo persistente em vez de executar o bot como uma função serverless.

## Estrutura do pacote

```text
BotPilotAI-PWA/
├── web/          # interface instalável no iPhone
├── src/          # backend + Discord + IA
├── Dockerfile
├── docker-compose.yml
├── package.json
└── .env.example
```
