import { ChannelType } from 'discord.js';

function required(value, name) {
  if (value === null || value === undefined || value === '') throw new Error(`${name} is required for this action.`);
  return value;
}

export async function executePlan(client, guildId, plan) {
  const guild = await client.guilds.fetch(guildId);
  const results = [];

  for (const action of plan.actions) {
    try {
      let detail = '';
      switch (action.type) {
        case 'create_text_channel': {
          const channel = await guild.channels.create({ name: required(action.name, 'name'), type: ChannelType.GuildText, parent: action.parent_id || undefined, reason: action.reason || 'BotPilot AI' });
          detail = `Canal de texto criado: #${channel.name}`;
          break;
        }
        case 'create_voice_channel': {
          const channel = await guild.channels.create({ name: required(action.name, 'name'), type: ChannelType.GuildVoice, parent: action.parent_id || undefined, reason: action.reason || 'BotPilot AI' });
          detail = `Canal de voz criado: ${channel.name}`;
          break;
        }
        case 'create_category': {
          const channel = await guild.channels.create({ name: required(action.name, 'name'), type: ChannelType.GuildCategory, reason: action.reason || 'BotPilot AI' });
          detail = `Categoria criada: ${channel.name}`;
          break;
        }
        case 'rename_channel': {
          const channel = await guild.channels.fetch(required(action.channel_id, 'channel_id'));
          await channel.setName(required(action.name, 'name'), action.reason || 'BotPilot AI');
          detail = `Canal renomeado para ${action.name}`;
          break;
        }
        case 'delete_channel': {
          const channel = await guild.channels.fetch(required(action.channel_id, 'channel_id'));
          const oldName = channel.name;
          await channel.delete(action.reason || 'BotPilot AI');
          detail = `Canal removido: ${oldName}`;
          break;
        }
        case 'move_channel': {
          const channel = await guild.channels.fetch(required(action.channel_id, 'channel_id'));
          await channel.setParent(action.parent_id, { lockPermissions: false, reason: action.reason || 'BotPilot AI' });
          detail = `Canal movido: ${channel.name}`;
          break;
        }
        case 'set_channel_topic': {
          const channel = await guild.channels.fetch(required(action.channel_id, 'channel_id'));
          if (typeof channel.setTopic !== 'function') throw new Error('This channel does not support topics.');
          await channel.setTopic(action.topic ?? null, action.reason || 'BotPilot AI');
          detail = `Tópico atualizado em #${channel.name}`;
          break;
        }
        case 'set_slowmode': {
          const channel = await guild.channels.fetch(required(action.channel_id, 'channel_id'));
          if (typeof channel.setRateLimitPerUser !== 'function') throw new Error('This channel does not support slowmode.');
          await channel.setRateLimitPerUser(required(action.seconds, 'seconds'), action.reason || 'BotPilot AI');
          detail = `Modo lento atualizado em #${channel.name}`;
          break;
        }
        case 'send_message': {
          const channel = await guild.channels.fetch(required(action.channel_id, 'channel_id'));
          if (!channel.isTextBased() || typeof channel.send !== 'function') throw new Error('Target channel cannot receive messages.');
          await channel.send({ content: required(action.content, 'content'), allowedMentions: { parse: [] } });
          detail = `Mensagem enviada em #${channel.name}`;
          break;
        }
        case 'create_role': {
          const role = await guild.roles.create({ name: required(action.name, 'name'), reason: action.reason || 'BotPilot AI' });
          detail = `Cargo criado: ${role.name}`;
          break;
        }
        case 'rename_role': {
          const role = await guild.roles.fetch(required(action.role_id, 'role_id'));
          if (!role || role.managed) throw new Error('Role cannot be edited.');
          await role.setName(required(action.name, 'name'), action.reason || 'BotPilot AI');
          detail = `Cargo renomeado para ${action.name}`;
          break;
        }
        case 'delete_role': {
          const role = await guild.roles.fetch(required(action.role_id, 'role_id'));
          if (!role || role.managed) throw new Error('Role cannot be deleted.');
          const oldName = role.name;
          await role.delete(action.reason || 'BotPilot AI');
          detail = `Cargo removido: ${oldName}`;
          break;
        }
        case 'rename_server': {
          await guild.setName(required(action.name, 'name'), action.reason || 'BotPilot AI');
          detail = `Servidor renomeado para ${action.name}`;
          break;
        }
        default:
          throw new Error(`Unsupported action: ${action.type}`);
      }
      results.push({ type: action.type, ok: true, detail });
    } catch (error) {
      results.push({ type: action.type, ok: false, detail: error?.message || 'Unknown error' });
      break;
    }
  }
  return results;
}
