import { z } from 'zod/v4';

const ActionType = z.enum([
  'create_text_channel',
  'create_voice_channel',
  'create_category',
  'rename_channel',
  'delete_channel',
  'move_channel',
  'set_channel_topic',
  'set_slowmode',
  'send_message',
  'create_role',
  'rename_role',
  'delete_role',
  'rename_server'
]);

const Action = z.object({
  type: ActionType,
  channel_id: z.string().nullable(),
  role_id: z.string().nullable(),
  name: z.string().nullable(),
  content: z.string().nullable(),
  topic: z.string().nullable(),
  parent_id: z.string().nullable(),
  seconds: z.number().int().min(0).max(21600).nullable(),
  reason: z.string().nullable(),
});

const Plan = z.object({
  summary: z.string(),
  actions: z.array(Action).max(25),
});

function riskFor(actions) {
  if (actions.some((a) => ['delete_channel', 'delete_role'].includes(a.type))) return 'high';
  if (actions.some((a) => ['rename_server', 'move_channel', 'create_role', 'rename_role', 'rename_channel', 'create_text_channel', 'create_voice_channel', 'create_category'].includes(a.type))) return 'medium';
  return 'low';
}

const GROQ_ENDPOINT = process.env.GROQ_BASE_URL || 'https://api.groq.com/openai/v1/chat/completions';
const DEFAULT_GROQ_MODEL = 'openai/gpt-oss-20b';

export class AIPlanner {
  constructor() {
    this.apiKey = String(process.env.GROQ_API_KEY || '').trim();
    this.model = String(process.env.GROQ_MODEL || '').trim() || DEFAULT_GROQ_MODEL;
  }

  async plan(request, snapshot) {
    if (!this.apiKey) {
      throw new Error('A IA ainda não foi configurada neste servidor. Adicione GROQ_API_KEY nas variáveis do Render.');
    }

    const instructions = [
      'You are a Discord server administration planner.',
      'Turn the user request into a small, exact sequence of allowed actions.',
      'Never invent Discord IDs. Use only IDs present in the supplied snapshot.',
      'For create actions, IDs are null because the object does not exist yet.',
      'Do not plan bans, kicks, mass-DMs, token changes, permission escalation, webhooks, or actions outside the allowed action enum.',
      'If the request is ambiguous or unsupported, return an empty actions array and explain briefly in summary.',
      'Use Brazilian Portuguese in summary.',
      'Keep actions minimal and avoid destructive changes unless explicitly requested.',
      'Return only valid JSON with exactly this shape: {"summary":"string","actions":[{"type":"create_text_channel|create_voice_channel|create_category|rename_channel|delete_channel|move_channel|set_channel_topic|set_slowmode|send_message|create_role|rename_role|delete_role|rename_server","channel_id":"string or null","role_id":"string or null","name":"string or null","content":"string or null","topic":"string or null","parent_id":"string or null","seconds":"integer 0-21600 or null","reason":"string or null"}]}.'
    ].join('\n');

    const response = await fetch(GROQ_ENDPOINT, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: this.model,
        temperature: 0,
        max_tokens: 1200,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: instructions },
          { role: 'user', content: JSON.stringify({ user_request: request, discord_state: snapshot }) },
        ],
      }),
    });

    if (!response.ok) {
      let providerMessage = '';
      try {
        const body = await response.json();
        providerMessage = typeof body?.error?.message === 'string' ? body.error.message : '';
      } catch {}
      const suffix = providerMessage ? `: ${providerMessage}` : '';
      throw new Error(`Falha na API da Groq (${response.status})${suffix}`);
    }

    const payload = await response.json();
    const content = payload?.choices?.[0]?.message?.content;
    if (typeof content !== 'string' || !content.trim()) throw new Error('A Groq não retornou um plano válido.');

    let parsedJson;
    try {
      parsedJson = JSON.parse(content);
    } catch {
      throw new Error('A Groq retornou uma resposta que não é JSON válido.');
    }

    const parsed = Plan.safeParse(parsedJson);
    if (!parsed.success) throw new Error('A Groq retornou um plano fora do formato permitido.');
    return { ...parsed.data, risk: riskFor(parsed.data.actions) };
  }
}
