import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const dataFile = process.env.DATA_FILE || path.resolve('data/store.json');
const supabaseUrl = String(process.env.SUPABASE_URL || '').replace(/\/$/, '');
const supabaseKey = String(process.env.SUPABASE_SERVICE_ROLE_KEY || '');
const remoteStoreKey = String(process.env.SUPABASE_STORE_KEY || 'botpilot-main');
const keyFile = path.resolve('data/.master-key');

function getMasterKey() {
  if (process.env.MASTER_KEY) {
    const key = Buffer.from(process.env.MASTER_KEY, 'base64');
    if (key.length !== 32) throw new Error('MASTER_KEY must decode to exactly 32 bytes.');
    return key;
  }
  if (process.env.NODE_ENV === 'production') {
    throw new Error('MASTER_KEY is required in production.');
  }
  fs.mkdirSync(path.dirname(keyFile), { recursive: true });
  if (!fs.existsSync(keyFile)) fs.writeFileSync(keyFile, crypto.randomBytes(32).toString('base64'), { mode: 0o600 });
  return Buffer.from(fs.readFileSync(keyFile, 'utf8').trim(), 'base64');
}

const masterKey = getMasterKey();

function initialState() {
  return { devices: [], bots: [], history: [] };
}

export function loadStore() {
  fs.mkdirSync(path.dirname(dataFile), { recursive: true });
  if (!fs.existsSync(dataFile)) return initialState();
  try {
    const parsed = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
    return { ...initialState(), ...parsed };
  } catch {
    throw new Error(`Could not parse data store at ${dataFile}`);
  }
}

export function saveStore(state) {
  fs.mkdirSync(path.dirname(dataFile), { recursive: true });
  const tmp = `${dataFile}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(state, null, 2));
  fs.renameSync(tmp, dataFile);
  if (supabaseUrl && supabaseKey) void remoteSave(state).catch((error) => console.error('Remote store save failed:', error.message));
}

async function remoteSave(state) {
  const response = await fetch(`${supabaseUrl}/rest/v1/botpilot_store?on_conflict=store_key`, {
    method: 'POST',
    headers: {
      apikey: supabaseKey,
      Authorization: `Bearer ${supabaseKey}`,
      'Content-Type': 'application/json',
      Prefer: 'resolution=merge-duplicates,return=minimal'
    },
    body: JSON.stringify({ store_key: remoteStoreKey, payload: state, updated_at: new Date().toISOString() })
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
}

export async function hydrateStore(state) {
  if (!supabaseUrl || !supabaseKey) return state;
  const response = await fetch(`${supabaseUrl}/rest/v1/botpilot_store?select=payload&store_key=eq.${encodeURIComponent(remoteStoreKey)}&limit=1`, {
    headers: { apikey: supabaseKey, Authorization: `Bearer ${supabaseKey}` }
  });
  if (!response.ok) throw new Error(`Remote store load failed: HTTP ${response.status}`);
  const rows = await response.json();
  if (rows[0]?.payload) {
    Object.assign(state, { ...initialState(), ...rows[0].payload });
    fs.mkdirSync(path.dirname(dataFile), { recursive: true });
    fs.writeFileSync(dataFile, JSON.stringify(state, null, 2));
  }
  return state;
}

export function encryptSecret(plainText) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', masterKey, iv);
  const encrypted = Buffer.concat([cipher.update(plainText, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [iv, tag, encrypted].map((b) => b.toString('base64')).join('.');
}

export function decryptSecret(payload) {
  const [ivB64, tagB64, dataB64] = payload.split('.');
  const decipher = crypto.createDecipheriv('aes-256-gcm', masterKey, Buffer.from(ivB64, 'base64'));
  decipher.setAuthTag(Buffer.from(tagB64, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(dataB64, 'base64')), decipher.final()]).toString('utf8');
}

export function sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

export function publicBot(record, runtime = {}) {
  const { encryptedToken, ...safe } = record;
  return { ...safe, ...runtime };
}

export function appendHistory(state, entry) {
  state.history.unshift({ id: crypto.randomUUID(), at: new Date().toISOString(), ...entry });
  state.history = state.history.slice(0, 200);
}
