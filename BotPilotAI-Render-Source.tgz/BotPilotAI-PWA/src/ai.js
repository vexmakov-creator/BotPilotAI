import OpenAI from 'openai';
import { z } from 'zod/v4';
import { zodTextFormat } from 'openai/helpers/zod';

const ActionType = z.enum([
  'create_text_channel',
  'create_voice_channel',
  'create_category',
  'rename_channel',
  'delete_channel',
  'move_channel',
  'set_channel_topic',
  'set_slowmode',
  'send_message',
  'create_role',
  'rename_role',
  'delete_role',
  'rename_server'
]);

const Action = z.object({
  type: ActionType,
  channel_id: z.string().nullable(),
  role_id: z.string().nullable(),
  name: z.string().nullable(),
  content: z.string().nullable(),
  topic: z.string().nullable(),
  parent_id: z.string().nullable(),
  seconds: z.number().int().min(0).max(21600).nullable(),
  reason: z.string().nullable(),
});

const Plan = z.object({
  summary: z.string(),
  actions: z.array(Action).max(25),
});

function riskFor(actions) {
  if (actions.some((a) => ['delete_channel', 'delete_role'].includes(a.type))) return 'high';
  if (actions.some((a) => ['rename_server', 'move_channel', 'create_role', 'rename_role', 'rename_channel', 'create_text_channel', 'create_voice_channel', 'create_category'].includes(a.type))) return 'medium';
  return 'low';
}

export class AIPlanner {
  constructor() {
    this.client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
    this.model = process.env.OPENAI_MODEL || 'gpt-5.6';
  }

  async plan(request, snapshot) {
    if (!this.client) throw new Error('A IA ainda não foi configurada neste servidor. Adicione OPENAI_API_KEY nas variáveis do Render.');
    const response = await this.client.responses.parse({
      model: this.model,
      instructions: [
        'You are a Discord server administration planner.',
        'Turn the user request into a small, exact sequence of allowed actions.',
        'Never invent Discord IDs. Use only IDs present in the supplied snapshot.',
        'For create actions, IDs are null because the object does not exist yet.',
        'Do not plan bans, kicks, mass-DMs, token changes, permission escalation, webhooks, or actions outside the allowed action enum.',
        'If the request is ambiguous or unsupported, return an empty actions array and explain briefly in summary.',
        'Use Brazilian Portuguese in summary.',
        'Keep actions minimal and avoid destructive changes unless explicitly requested.'
      ].join('\n'),
      input: JSON.stringify({ user_request: request, discord_state: snapshot }),
      text: { format: zodTextFormat(Plan, 'discord_admin_plan') },
    });

    const parsed = response.output_parsed;
    if (!parsed) throw new Error('AI did not return a valid plan.');
    return { ...parsed, risk: riskFor(parsed.actions) };
  }
}
